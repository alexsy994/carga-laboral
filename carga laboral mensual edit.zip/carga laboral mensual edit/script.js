function agregarFila() {
    var tabla = document.getElementById("tabla").getElementsByTagName('tbody')[0];
    var nuevaFila = tabla.insertRow();

    for (var i = 0; i < 10; i++) {
        var celda = nuevaFila.insertCell(i);
        var contenido = "";

        if (i === 0) {
            contenido = contenido = "<select><option value='Seleccionar'>Seleccionar</option><option value='Ingeniero'>Ingeniero</option><option value='Técnico'>Técnico</option></select>";

        } else if (i === 1) {
            contenido = "<div contenteditable='true'></div>";
        } else if (i === 2) {
            contenido = "<select>";
            for (var j = 1; j <= 5; j++) {
                contenido += "<option value='" + j + "'>" + j + "</option>";
            }
            contenido += "</select>";
        } else if (i === 3) {
            contenido = "52";
           
        } else if (i === 4) {
            contenido = "<select>";
            for (var k = 0; k <= 20; k++) {
                contenido += "<option value='" + k + "'>" + k + "</option>";
            }
            contenido += "</select>";
        } else if (i === 5) {
            contenido = "<select><option value='0'>0</option><option value='15'>15</option><option value='30'>30</option></select>";
        } else if (i === 6) {
            contenido = "<select>";
            for (var l = 1; l <= 9; l++) {
                contenido += "<option value='" + l + "'>" + l + "</option>";
            }
            contenido += "</select>";
        } else if (i === 7) {
            contenido = "<select><option value='1'>1 hora</option><option value='0.5'>30 minutos</option><option value='0'>0</option></select>";
        } else if (i === 8) {
            contenido = "<select><option value='0.65'>65%</option><option value='0.70'>70%</option></select>";
        } else if (i === 9) {
            contenido = "";
        } else {
            contenido = "Editar";
        }

        celda.innerHTML = contenido;
        if (i !== 0 && i !== 1 && i !== 9) {
            celda.setAttribute("contenteditable", true);
        }
    }

    calcularCargaLaboral(nuevaFila);
}

function calcularCargaLaboral(fila) {
    var diasLaboralesSemana = parseInt(fila.cells[2].querySelector('select').value);
    var semanasAnio = parseInt(fila.cells[3].innerHTML);
    var diasFestivos = parseInt(fila.cells[4].querySelector('select').value);
    var vacaciones = parseInt(fila.cells[5].querySelector('select').value);
    var horasLaboralesDiarios = parseInt(fila.cells[6].querySelector('select').value);
    var horaComida = parseFloat(fila.cells[7].querySelector('select').value);
    var productividad = parseFloat(fila.cells[8].querySelector('select').value);
    var cargaLaboral = (((diasLaboralesSemana * semanasAnio) - (diasFestivos + vacaciones)) * (horasLaboralesDiarios - horaComida) * productividad) / 12;

    var celdaCargaLaboral = fila.cells[9];
    celdaCargaLaboral.innerHTML = cargaLaboral.toFixed(2);
}

document.getElementById("tabla").addEventListener('change', function(event) {
    var fila = event.target.closest('tr');
    if (fila) {
        calcularCargaLaboral(fila);
    }
});

// Eliminamos la función que ordena automáticamente al cargar la página

function mostrarValoresSinOrdenar() {
    var filas = document.getElementById("tabla").getElementsByTagName("tbody")[0].getElementsByTagName("tr");

    var nuevaTabla = document.createElement("table");
    nuevaTabla.id = "tablaSinOrden";
    var thead = document.createElement("thead");
    var tr = document.createElement("tr");
    var thEspecialidad = document.createElement("th");
    thEspecialidad.textContent = "Especialidad";
    var thNombre = document.createElement("th");
    thNombre.textContent = "Nombre";
    var thCargaLaboral = document.createElement("th");
    thCargaLaboral.textContent = "Carga Laboral";
    tr.appendChild(thEspecialidad);
    tr.appendChild(thNombre);
    tr.appendChild(thCargaLaboral);
    thead.appendChild(tr);
    nuevaTabla.appendChild(thead);

    var tbody = document.createElement("tbody");
    for (var i = 0; i < filas.length; i++) {
        var fila = document.createElement("tr");

        var celdaEspecialidad = document.createElement("td");
        celdaEspecialidad.textContent = filas[i].cells[0].querySelector('select').value; // Obtener la especialidad
        fila.appendChild(celdaEspecialidad);

        var celdaNombre = document.createElement("td");
        celdaNombre.textContent = filas[i].cells[1].innerText.trim();
        fila.appendChild(celdaNombre);

        var celdaCargaLaboral = document.createElement("td");
        celdaCargaLaboral.textContent = filas[i].cells[9].innerText.trim();
        fila.appendChild(celdaCargaLaboral);

        tbody.appendChild(fila);
    }
    nuevaTabla.appendChild(tbody);

    document.body.appendChild(nuevaTabla);
}

document.querySelector("button:last-of-type").addEventListener("click", mostrarValoresSinOrdenar);

window.onload = function() {
    mostrarValoresSinOrdenar();
};